import React from "react";
import { Badge } from "../../components/ui/badge";
import { CallToActionSection } from "./sections/CallToActionSection";
import { CaseStudiesSection } from "./sections/CaseStudiesSection";
import { ContactFormSection } from "./sections/ContactFormSection";
import { FeaturesSection } from "./sections/FeaturesSection";
import { FooterSection } from "./sections/FooterSection";
import { HeroSection } from "./sections/HeroSection";
import { ProcessSection } from "./sections/ProcessSection/ProcessSection";
import { ServicesSection } from "./sections/ServicesSection";
import { TestimonialsSection } from "./sections/TestimonialsSection/TestimonialsSection";

export const Home = (): JSX.Element => {
  // Section header data for consistent styling
  const sectionHeaders = [
    {
      id: "services",
      badge: "Services",
      badgeColor: "bg-green",
      textColor: "text-white-text",
      description:
        "At our digital marketing agency, we offer a range of services to help businesses grow and succeed online. These services include:",
      position: "top-[971px]",
    },
    {
      id: "caseStudies",
      badge: "Case Studies",
      badgeColor: "bg-[#5e17eb]",
      textColor: "text-white",
      description:
        "Explore Real-Life Examples of Our Proven Digital Marketing Success through Our Case Studies",
      position: "top-[2746px]",
    },
    {
      id: "process",
      badge: "Our Working Process",
      badgeColor: "bg-green",
      textColor: "text-white",
      description: "Step-by-Step Guide to Achieving Your Business Goals",
      descriptionWidth: "w-[292px]",
      position: "top-[3343px]",
    },
    {
      id: "team",
      badge: "Team",
      badgeColor: "bg-green",
      textColor: "text-[#000000]",
      description:
        "Meet the skilled and experienced team behind our successful digital marketing strategies",
      descriptionWidth: "w-[473px]",
      position: "top-[4838px]",
    },
    {
      id: "testimonials",
      badge: "Testimonials",
      badgeColor: "bg-green",
      textColor: "text-[#000000]",
      description:
        "Hear from Our Satisfied Clients: Read Our Testimonials to Learn More about Our Digital Marketing Services",
      descriptionWidth: "w-[473px]",
      position: "top-[5902px]",
    },
    {
      id: "contact",
      badge: "Contact Us",
      badgeColor: "bg-green",
      textColor: "text-[#000000]",
      description:
        "Connect with Us: Let's Discuss Your Digital Marketing Needs",
      descriptionWidth: "w-[323px]",
      position: "top-[6798px]",
    },
  ];

  return (
    <div className="bg-white flex flex-row justify-center w-full">
      <div className="bg-white overflow-x-hidden w-full max-w-[1440px] relative">
        {/* Section Headers */}
        {sectionHeaders.map((header) => (
          <div
            key={header.id}
            className={`flex w-full max-w-[1440px] items-start gap-10 px-[100px] py-0 absolute ${header.position} left-0`}
          >
            <div className="inline-flex flex-col items-start relative flex-[0_0_auto]">
              <Badge
                className={`px-[7px] py-0 ${header.badgeColor} rounded-[7px]`}
              >
                <span
                  className={`font-h-2 font-[number:var(--h-2-font-weight)] ${header.textColor} text-[length:var(--h-2-font-size)] tracking-[var(--h-2-letter-spacing)] leading-[var(--h-2-line-height)] [font-style:var(--h-2-font-style)]`}
                >
                  {header.badge}
                </span>
              </Badge>
            </div>

            <div
              className={`relative ${header.descriptionWidth || "w-[580px]"} mt-[-1.00px] font-p font-[number:var(--p-font-weight)] text-[#000000] text-[length:var(--p-font-size)] tracking-[var(--p-letter-spacing)] leading-[var(--p-line-height)] [font-style:var(--p-font-style)]`}
            >
              {header.description}
            </div>
          </div>
        ))}

        {/* Main Sections */}
        <HeroSection />
        <ServicesSection />
        <CallToActionSection />
        <CaseStudiesSection />
        <ProcessSection />
        <FeaturesSection />
        <TestimonialsSection />
        <ContactFormSection />
        <FooterSection />
      </div>
    </div>
  );
};

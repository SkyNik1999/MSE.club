import React from "react";
import { Button } from "../../../../components/ui/button";
import { Card, CardContent } from "../../../../components/ui/card";
import { Input } from "../../../../components/ui/input";
import { Label } from "../../../../components/ui/label";
import {
  RadioGroup,
  RadioGroupItem,
} from "../../../../components/ui/radio-group";
import { Textarea } from "../../../../components/ui/textarea";

export const ContactFormSection = (): JSX.Element => {
  // Form options data
  const contactOptions = [
    { id: "say-hi", label: "Say Hi", selected: true },
    { id: "get-quote", label: "Get a Quote", selected: false },
  ];

  // Form fields data
  const formFields = [
    { id: "name", label: "Name", required: false, type: "input" },
    { id: "email", label: "Email*", required: true, type: "input" },
    { id: "message", label: "Message*", required: true, type: "textarea" },
  ];

  return (
    <section className="flex w-full items-center px-[100px] py-0 relative">
      <Card className="flex w-full items-start gap-2.5 pt-[60px] pb-20 px-[100px] relative bg-grey rounded-[45px] border-none">
        <CardContent className="p-0">
          <div className="flex flex-col items-start gap-10">
            {/* Contact Type Selection */}
            <RadioGroup
              defaultValue="say-hi"
              className="flex items-start gap-[35px]"
            >
              {contactOptions.map((option) => (
                <div key={option.id} className="flex items-center gap-3">
                  <div className="relative w-7 h-7">
                    <div className="relative w-[30px] h-[30px] bg-white rounded-[29px] border border-solid border-[#000000] flex items-center justify-center">
                      {option.selected && (
                        <div className="w-4 h-4 bg-green rounded-lg" />
                      )}
                    </div>
                  </div>
                  <Label
                    htmlFor={option.id}
                    className="font-p font-[number:var(--p-font-weight)] text-[#000000] text-[length:var(--p-font-size)] tracking-[var(--p-letter-spacing)] leading-[var(--p-line-height)] [font-style:var(--p-font-style)]"
                  >
                    {option.label}
                  </Label>
                  <RadioGroupItem
                    value={option.id}
                    id={option.id}
                    className="sr-only"
                  />
                </div>
              ))}
            </RadioGroup>

            {/* Form Fields */}
            <div className="flex flex-col items-start gap-[25px] w-[556px]">
              {formFields.map((field) => (
                <div key={field.id} className="flex flex-col gap-[5px] w-full">
                  <Label
                    htmlFor={field.id}
                    className="text-[#000000] text-base leading-7 [font-family:'Space_Grotesk',Helvetica] font-normal tracking-[0]"
                  >
                    {field.label}
                  </Label>

                  {field.type === "input" ? (
                    <Input
                      id={field.id}
                      placeholder={
                        field.id.charAt(0).toUpperCase() + field.id.slice(1)
                      }
                      className="w-full px-[30px] py-[18px] bg-white rounded-[14px] border border-solid border-[#000000] text-lg [font-family:'Space_Grotesk',Helvetica] font-normal h-auto"
                    />
                  ) : (
                    <Textarea
                      id={field.id}
                      placeholder={
                        field.id.charAt(0).toUpperCase() + field.id.slice(1)
                      }
                      className="h-[190px] w-full px-[30px] py-[18px] bg-white rounded-[14px] border border-solid border-[#000000] text-lg [font-family:'Space_Grotesk',Helvetica] font-normal resize-none"
                    />
                  )}
                </div>
              ))}
            </div>

            {/* Submit Button */}
            <Button className="w-[556px] flex items-center justify-center bg-dark gap-2.5 px-[35px] py-5 rounded-[14px] [font-family:'Space_Grotesk',Helvetica] font-normal text-white text-xl text-center tracking-[0] leading-7 h-auto">
              Send Message
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Decorative Elements */}
      <div className="relative w-[691.57px] h-[648px] mr-[-324.57px] ml-[-367px]">
        <div className="relative w-[692px] h-[648px]">
          <img
            className="absolute w-[650px] h-[648px] top-0 left-[42px]"
            alt="Mask group"
            src="/mask-group-6.png"
          />
          <img
            className="absolute w-[141px] h-[141px] top-[424px] left-0"
            alt="Vector"
            src="/vector-11.svg"
          />
          <img
            className="absolute w-[253px] h-[253px] top-[162px] left-[46px]"
            alt="Vector"
            src="/vector-11.svg"
          />
        </div>
      </div>
    </section>
  );
};

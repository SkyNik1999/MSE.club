import { LinkedinIcon } from "lucide-react";
import React from "react";
import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from "../../../../components/ui/avatar";
import { Card, CardContent } from "../../../../components/ui/card";
import { Separator } from "../../../../components/ui/separator";

// Team member data for easier mapping
const teamMembers = [
  {
    id: 1,
    name: "Nikhil Gupta",
    position: "CEO and Founder",
    description:
      "10+ years of experience in digital marketing. Expertise in SEO, PPC, and content strategy",
    image: "/mask-group.png",
    vectorImage: "/vector.svg",
  },
  {
    id: 2,
    name: "Jay Fataniya",
    position: "Co-Founder",
    description:
      "7+ years of experience in project management and team leadership. Strong organizational and communication skills",
    image: "/mask-group-1.png",
    vectorImage: "/vector.svg",
  },
  {
    id: 3,
    name: "Rumela",
    position: "CTO",
    description:
      "5+ years of experience in SEO and content creation. Proficient in keyword research and on-page optimization",
    image: "/mask-group-2.png",
    vectorImage: "/vector.svg",
  },
  {
    id: 4,
    name: "HR Bhuvi",
    position: "HR Manager",
    description:
      "3+ years of experience in paid search advertising. Skilled in campaign management and performance analysis",
    image: "/mask-group-3.png",
    vectorImage: "/vector.svg",
  },
  {
    id: 5,
    name: "Brian Williams",
    position: "Social Media Specialist",
    description:
      "4+ years of experience in social media marketing. Proficient in creating and scheduling content, analyzing metrics, and building engagement",
    image: "/mask-group-4.png",
    vectorImage: "/vector.svg",
  },
  {
    id: 6,
    name: "Sarah Kim",
    position: "Content Creator",
    description:
      "2+ years of experience in writing and editing\nSkilled in creating compelling, SEO-optimized content for various industries",
    image: "/mask-group-5.png",
    vectorImage: "/vector.svg",
  },
];

export const FeaturesSection = (): JSX.Element => {
  // Split team members into two rows
  const firstRow = teamMembers.slice(0, 3);
  const secondRow = teamMembers.slice(3, 6);

  return (
    <section className="flex flex-col gap-10 w-full py-10">
      {/* First row of team members */}
      <div className="flex flex-wrap justify-center gap-10 px-[100px]">
        {firstRow.map((member) => (
          <TeamMemberCard key={member.id} member={member} />
        ))}
      </div>

      {/* Second row of team members */}
      <div className="flex flex-wrap justify-center gap-10 px-[100px]">
        {secondRow.map((member) => (
          <TeamMemberCard key={member.id} member={member} />
        ))}
      </div>
    </section>
  );
};

// Team member card component
const TeamMemberCard = ({ member }) => {
  return (
    <Card className="w-[387px] rounded-[45px] border border-solid border-[#191a23] shadow-[0px_5px_0px_#191a23] overflow-hidden">
      <CardContent className="p-[35px] pt-10">
        <div className="flex flex-col gap-7">
          {/* Header with avatar, name, position and LinkedIn button */}
          <div className="flex items-start w-full">
            <div className="flex items-end gap-5 flex-1 pr-[76px]">
              {/* Avatar with background vector */}
              <div className="relative w-[103px] h-[103px]">
                <img
                  className="absolute w-[98px] h-[98px] top-[5px] left-[5px]"
                  alt="Vector"
                  src={member.vectorImage}
                />
                <Avatar className="w-[98px] h-[98px] absolute top-0 left-0">
                  <AvatarImage src={member.image} alt={member.name} />
                  <AvatarFallback>{member.name.charAt(0)}</AvatarFallback>
                </Avatar>
              </div>

              {/* Name and position */}
              <div className="relative">
                <h4 className="font-h-4 font-[number:var(--h-4-font-weight)] text-[#000000] text-[length:var(--h-4-font-size)] tracking-[var(--h-4-letter-spacing)] leading-[var(--h-4-line-height)] [font-style:var(--h-4-font-style)]">
                  {member.name}
                </h4>
                <p className="mt-[26px] font-p font-[number:var(--p-font-weight)] text-[#000000] text-[length:var(--p-font-size)] tracking-[var(--p-letter-spacing)] leading-[var(--p-line-height)] [font-style:var(--p-font-style)]">
                  {member.position}
                </p>
              </div>
            </div>

            {/* LinkedIn button */}
            <div className="relative w-[34px] h-[34px] ml-[-67px] bg-[#000000] rounded-[17px] flex items-center justify-center">
              <LinkedinIcon className="w-[17px] h-[17px] text-white" />
            </div>
          </div>

          {/* Separator line */}
          <Separator className="w-[317px] bg-black/10" />

          {/* Description */}
          <p className="w-[317px] font-p font-[number:var(--p-font-weight)] text-[#000000] text-[length:var(--p-font-size)] tracking-[var(--p-letter-spacing)] leading-[var(--p-line-height)] [font-style:var(--p-font-style)]">
            {member.description}
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

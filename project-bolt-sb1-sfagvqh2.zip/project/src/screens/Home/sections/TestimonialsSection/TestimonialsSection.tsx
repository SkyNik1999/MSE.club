import React from "react";
import { Card, CardContent } from "../../../../components/ui/card";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "../../../../components/ui/carousel";

export const TestimonialsSection = (): JSX.Element => {
  // Testimonial data for mapping
  const testimonials = [
    {
      id: 1,
      quote:
        '"We have been working with Positivus for the past year and have seen a significant increase in website traffic and leads as a result of their efforts. The team is professional, responsive, and truly cares about the success of our business. We highly recommend Positivus to any company looking to grow their online presence."',
      name: "John Smith",
      position: "Marketing Director at XYZ Corp",
      bubbleImage: "/bubble.svg",
      bubblePosition: "right",
    },
    {
      id: 2,
      quote:
        '"We have been working with Positivus for the past year and have seen a significant increase in website traffic and leads as a result of their efforts. The team is professional, responsive, and truly cares about the success of our business. We highly recommend Positivus to any company looking to grow their online presence."',
      name: "John Smith",
      position: "Marketing Director at XYZ Corp",
      bubbleImage: "/bubble-1.svg",
      bubblePosition: "full",
    },
    {
      id: 3,
      quote:
        '"We have been working with Positivus for the past year and have seen a significant increase in website traffic and leads as a result of their efforts. The team is professional, responsive, and truly cares about the success of our business. We highly recommend Positivus to any company looking to grow their online presence."',
      name: "John Smith",
      position: "Marketing Director at XYZ Corp",
      bubbleImage: "/bubble-2.svg",
      bubblePosition: "left",
    },
  ];

  return (
    <section className="w-full max-w-[1240px] mx-auto my-8 bg-dark rounded-[45px] overflow-hidden py-20">
      <Carousel className="w-full">
        <CarouselContent>
          {testimonials.map((testimonial) => (
            <CarouselItem key={testimonial.id}>
              <div className="flex flex-col items-end gap-5 px-12">
                <Card className="w-full max-w-[606px] bg-transparent border-none">
                  <CardContent className="p-0 relative">
                    <div className="relative w-full h-[266px]">
                      {testimonial.bubblePosition === "right" && (
                        <img
                          className="absolute w-[260px] h-[266px] top-0 right-0"
                          alt="Bubble"
                          src={testimonial.bubbleImage}
                        />
                      )}
                      {testimonial.bubblePosition === "left" && (
                        <img
                          className="absolute w-[274px] h-[266px] top-0 left-0"
                          alt="Bubble"
                          src={testimonial.bubbleImage}
                        />
                      )}
                      {testimonial.bubblePosition === "full" && (
                        <div className="absolute inset-0 bg-[url(/bubble-1.svg)] bg-[100%_100%]" />
                      )}
                      <div className="absolute w-[502px] top-[47px] left-[52px] font-p font-[number:var(--p-font-weight)] text-white text-[length:var(--p-font-size)] tracking-[var(--p-letter-spacing)] leading-[var(--p-line-height)] [font-style:var(--p-font-style)]">
                        {testimonial.quote}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <div className="w-[526px] [font-family:'Space_Grotesk',Helvetica] font-normal text-transparent text-xl tracking-[0] leading-5">
                  <span className="font-[number:var(--h-4-font-weight)] text-[#5e17eb] font-h-4 [font-style:var(--h-4-font-style)] tracking-[var(--h-4-letter-spacing)] leading-[var(--h-4-line-height)] text-[length:var(--h-4-font-size)]">
                    {testimonial.name}
                    <br />
                  </span>
                  <span className="text-white text-lg">
                    {testimonial.position}
                  </span>
                </div>
              </div>
            </CarouselItem>
          ))}
        </CarouselContent>

        <div className="flex justify-center items-center mt-20">
          <CarouselPrevious className="relative static transform-none h-auto w-auto bg-transparent border-none hover:bg-transparent hover:opacity-80">
            <img
              className="w-[23px] h-[22px]"
              alt="Previous"
              src="/arrow-3-1.svg"
            />
          </CarouselPrevious>

          <div className="relative w-[146px] h-3.5 mx-10 bg-[url(/stars.png)] bg-[100%_100%]" />

          <CarouselNext className="relative static transform-none h-auto w-auto bg-transparent border-none hover:bg-transparent hover:opacity-80">
            <img
              className="w-[23px] h-[22px] rotate-180"
              alt="Next"
              src="/arrow-3.svg"
            />
          </CarouselNext>
        </div>
      </Carousel>
    </section>
  );
};

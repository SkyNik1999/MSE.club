import React from "react";
import { Button } from "../../../../components/ui/button";
import { Card, CardContent } from "../../../../components/ui/card";
import { Input } from "../../../../components/ui/input";
import { Separator } from "../../../../components/ui/separator";

export const FooterSection = (): JSX.Element => {
  // Navigation links data
  const navLinks = ["About us", "Services", "Use Cases", "Pricing", "Blog"];

  // Contact information data
  const contactInfo = [
    "Email: info@positivus.com",
    "Phone: 555-567-8901",
    "Address: 1234 Main St\nMoonstone City, Stardust State 12345",
  ];

  return (
    <footer className="w-full px-[100px] py-0 mt-[7842px]">
      <Card className="gap-[50px] pt-[55px] pb-[50px] px-[60px] bg-dark rounded-[45px_45px_0px_0px] flex flex-col items-start">
        <CardContent className="p-0 flex flex-col items-start gap-[66px] w-full">
          {/* Top section with logo, navigation and social icons */}
          <div className="flex w-full items-center justify-between gap-[155px]">
            <img className="w-[180px] h-[29px]" alt="Logo" src="/logo.svg" />

            <nav className="flex items-start gap-10">
              {navLinks.map((link, index) => (
                <a
                  key={index}
                  href="#"
                  className="w-fit mt-[-1.00px] font-p font-normal text-white text-lg tracking-[0] leading-[normal] underline"
                >
                  {link}
                </a>
              ))}
            </nav>

            <div className="flex items-start gap-5">
              <div className="bg-white rounded-[15px] w-[30px] h-[30px] flex items-center justify-center">
                <img
                  className="w-[15px] h-[15px]"
                  alt="Linkedin"
                  src="/linkedin.svg"
                />
              </div>

              <img
                className="w-[30px] h-[30px]"
                alt="Social icon"
                src="/social-icon.svg"
              />

              <div className="bg-white rounded-[15px] w-[30px] h-[30px] flex items-center justify-center">
                <img
                  className="w-[18px] h-3.5"
                  alt="Twitter"
                  src="/twitter.svg"
                />
              </div>
            </div>
          </div>

          {/* Middle section with contact info and newsletter subscription */}
          <div className="flex items-start justify-between w-full gap-[154px]">
            {/* Contact information */}
            <div className="flex flex-col items-start gap-[27px]">
              <div className="flex flex-col items-start">
                <div className="flex flex-col items-start gap-2.5 px-[7px] py-0 bg-green rounded-[7px]">
                  <h4 className="w-fit mt-[-1.00px] font-h-4 font-[number:var(--h-4-font-weight)] text-[#000000] text-[length:var(--h-4-font-size)] tracking-[var(--h-4-letter-spacing)] leading-[var(--h-4-line-height)] [font-style:var(--h-4-font-style)]">
                    Contact us:
                  </h4>
                </div>
              </div>

              <div className="flex flex-col items-start gap-5">
                {contactInfo.map((info, index) => (
                  <p
                    key={index}
                    className="text-white text-[length:var(--p-font-size)] leading-[var(--p-line-height)] w-fit mt-[-1.00px] font-p font-[number:var(--p-font-weight)] tracking-[var(--p-letter-spacing)] [font-style:var(--p-font-style)]"
                  >
                    {info.includes("\n") ? (
                      <>
                        {info.split("\n")[0]}
                        <br />
                        {info.split("\n")[1]}
                      </>
                    ) : (
                      info
                    )}
                  </p>
                ))}
              </div>
            </div>

            {/* Newsletter subscription */}
            <Card className="flex items-start gap-5 px-10 py-[58px] bg-[#292a32] rounded-[14px] overflow-hidden border-none">
              <CardContent className="p-0 flex items-center gap-5">
                <Input
                  className="w-[285px] h-auto gap-2.5 px-[35px] py-[22px] rounded-[14px] overflow-hidden border border-solid border-white text-white bg-transparent"
                  placeholder="Email"
                />
                <Button className="h-auto bg-green gap-2.5 px-[35px] py-5 rounded-[14px] hover:bg-green/90">
                  <span className="font-p font-normal text-black text-xl text-center tracking-[0] leading-7 whitespace-nowrap">
                    Subscribe to news
                  </span>
                </Button>
              </CardContent>
            </Card>
          </div>
        </CardContent>

        {/* Bottom section with divider and copyright */}
        <div className="flex flex-col items-start gap-[50px] w-full">
          <Separator className="w-full h-px bg-white/20" />

          <div className="flex items-start gap-10">
            <p className="w-fit mt-[-1.00px] font-p font-normal text-white text-lg tracking-[0] leading-7 whitespace-nowrap">
              © 2023 Positivus. All Rights Reserved.
            </p>

            <a
              href="#"
              className="w-fit mt-[-1.00px] font-p font-normal text-white text-lg tracking-[0] leading-7 underline whitespace-nowrap"
            >
              Privacy Policy
            </a>
          </div>
        </div>
      </Card>
    </footer>
  );
};

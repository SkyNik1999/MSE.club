import React from "react";
import { Button } from "../../../../components/ui/button";
import {
  NavigationMenu,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
} from "../../../../components/ui/navigation-menu";

export const HeroSection = (): JSX.Element => {
  // Navigation menu items
  const navItems = [
    { label: "About us", href: "#" },
    { label: "Services", href: "#" },
    { label: "Use Cases", href: "#" },
    { label: "Pricing", href: "#" },
    { label: "Blog", href: "#" },
  ];

  // Company logos
  const companyLogos = [
    { src: "/company-logo-1.svg", alt: "Company logo" },
    { src: "/company-logo-3.svg", alt: "Company logo" },
    { src: "/company-logo.svg", alt: "Company logo" },
    { src: "/company-logo-2.svg", alt: "Company logo" },
    { src: "/company-logo-4.svg", alt: "Company logo" },
    { src: "/company-logo-5.svg", alt: "Company logo" },
  ];

  return (
    <div className="flex flex-col w-full items-start gap-[70px] relative">
      {/* Navigation Bar */}
      <div className="flex w-full items-center justify-between px-[100px] py-0 relative">
        <div className="flex items-start gap-2.5 px-0 py-2.5 relative">
          <img
            className="relative w-[219.54px] h-9"
            alt="Logo"
            src="/logo.svg"
          />
        </div>

        <NavigationMenu>
          <NavigationMenuList className="flex items-center gap-10">
            {navItems.map((item, index) => (
              <NavigationMenuItem key={index}>
                <NavigationMenuLink className="font-['Space_Grotesk',Helvetica] font-normal text-[#000000] text-xl leading-7">
                  {item.label}
                </NavigationMenuLink>
              </NavigationMenuItem>
            ))}
            <Button
              variant="outline"
              className="border border-solid border-[#191a23] px-[35px] py-5 rounded-[14px] font-['Space_Grotesk',Helvetica] font-normal text-[#000000] text-xl"
            >
              Request a quote
            </Button>
          </NavigationMenuList>
        </NavigationMenu>
      </div>

      {/* Hero Content */}
      <header className="flex w-full items-start justify-between px-[100px] py-0 relative bg-transparent">
        <div className="flex flex-col items-start gap-[35px] relative">
          <h1 className="relative w-[531px] mt-[-1.00px] font-h-1 font-[number:var(--h-1-font-weight)] text-[#000000] text-[length:var(--h-1-font-size)] tracking-[var(--h-1-letter-spacing)] leading-[var(--h-1-line-height)] [font-style:var(--h-1-font-style)]">
            Navigating the digital landscape for success
          </h1>

          <p className="relative w-[498px] font-['Space_Grotesk',Helvetica] font-normal text-[#000000] text-xl tracking-[0] leading-7">
            Our digital marketing agency helps businesses grow and succeed
            online through a range of services including SEO, PPC, social media
            marketing, and content creation.
          </p>

          <Button className="bg-dark text-white px-[35px] py-5 rounded-[14px] font-['Space_Grotesk',Helvetica] font-normal text-xl">
            Book a consultation
          </Button>
        </div>

        {/* Hero Illustration */}
        <div className="relative w-[600.46px] h-[515px]">
          <div className="relative w-[600px] h-[515px]">
            <img
              className="absolute w-9 h-9 top-[427px] left-[293px]"
              alt="Frame"
              src="/frame.svg"
            />

            <div className="absolute w-[600px] h-[515px] top-0 left-0">
              <img
                className="absolute w-[99px] h-[99px] top-[313px] left-[58px]"
                alt="Frame"
                src="/frame-1.svg"
              />

              <div className="absolute w-[566px] h-[119px] top-[193px] left-[34px] rounded-[283.13px/59.47px] border border-solid border-[#000000] rotate-[28.88deg]" />
              <div className="absolute w-[566px] h-[119px] top-[230px] left-3.5 rounded-[283.13px/59.47px] border border-solid border-[#000000] rotate-[28.88deg]" />
              <div className="absolute w-[566px] h-[119px] top-[267px] -left-1.5 rounded-[283.13px/59.47px] border border-solid border-[#000000] rotate-[28.88deg]" />

              <div className="absolute w-[446px] h-[385px] top-0 left-[154px]">
                <div className="relative h-[385px]">
                  <div className="absolute w-[341px] h-[368px] top-[17px] left-0">
                    <div className="h-[368px]">
                      <div className="relative w-[341px] h-[368px]">
                        <img
                          className="absolute w-16 h-[134px] top-[234px] left-24"
                          alt="Group"
                          src="/group.png"
                        />
                        <img
                          className="absolute w-[274px] h-[236px] top-[38px] left-px"
                          alt="Vector"
                          src="/vector-12.svg"
                        />
                        <img
                          className="absolute w-[214px] h-[278px] top-0 left-[126px]"
                          alt="Group"
                          src="/group-1.png"
                        />
                        <img
                          className="absolute w-[154px] h-[235px] top-[21px] left-[156px]"
                          alt="Vector"
                          src="/vector-8.svg"
                        />
                        <img
                          className="absolute w-[50px] h-16 top-[114px] left-[194px]"
                          alt="Group"
                          src="/group-2.png"
                        />
                        <img
                          className="absolute w-[135px] h-[206px] top-9 left-[166px]"
                          alt="Vector"
                          src="/vector-6.svg"
                        />
                        <img
                          className="absolute w-[276px] h-[238px] top-[37px] left-0"
                          alt="Vector"
                          src="/vector-7.svg"
                        />
                        <img
                          className="absolute w-[164px] h-[219px] top-[37px] left-28"
                          alt="Group"
                          src="/group-3.png"
                        />
                        <img
                          className="absolute w-10 h-[57px] top-[218px] left-0"
                          alt="Vector"
                          src="/vector-14.svg"
                        />
                        <img
                          className="absolute w-[42px] h-[58px] top-[217px] left-0"
                          alt="Group"
                          src="/group-4.png"
                        />
                        <img
                          className="absolute w-[72px] h-[87px] top-[188px] left-2.5"
                          alt="Group"
                          src="/group-5.png"
                        />
                        <img
                          className="absolute w-[57px] h-[73px] top-[119px] left-[177px]"
                          alt="Group"
                          src="/group-6.png"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="absolute w-48 h-[316px] top-0 left-[255px]">
                    <div className="absolute w-48 h-[107px] top-0 left-0">
                      <div className="absolute w-[99px] h-[99px] top-0 left-0 bg-[url(/vector-10.svg)] bg-[100%_100%]">
                        <img
                          className="absolute w-[38px] h-[35px] top-[35px] left-[31px]"
                          alt="Group"
                          src="/group-8.png"
                        />
                      </div>
                      <div className="absolute w-[95px] h-[95px] top-3 left-[97px] bg-[url(/group-9.png)] bg-[100%_100%]">
                        <img
                          className="absolute w-[34px] h-[30px] top-8 left-[29px]"
                          alt="Vector"
                          src="/vector-9.svg"
                        />
                      </div>
                    </div>
                    <img
                      className="absolute w-[94px] h-[94px] top-[115px] left-[87px]"
                      alt="Group"
                      src="/group-7.png"
                    />
                    <div className="absolute w-[102px] h-[102px] top-[215px] left-[67px] bg-[url(/group-10.png)] bg-[100%_100%]">
                      <img
                        className="absolute w-[39px] h-[58px] top-6 left-[31px]"
                        alt="Group"
                        src="/group-11.png"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="absolute w-[31px] h-[31px] top-[89px] left-[116px] bg-[#5e17eb] rounded-[15.5px]" />
            <div className="absolute w-5 h-5 top-[425px] left-[411px] bg-[#5e17eb] rounded-[10px]" />
            <div className="absolute w-[47px] h-[47px] top-[41px] left-[58px] bg-[#000000] rounded-[23.5px]" />
          </div>
        </div>
      </header>

      {/* Company Logos */}
      <div className="flex w-full items-start justify-between px-[100px] py-0 relative">
        {companyLogos.map((logo, index) => (
          <img
            key={index}
            className={`relative h-12 ${
              index === 0
                ? "w-[124.11px]"
                : index === 1
                  ? "w-[126.37px]"
                  : index === 2
                    ? "w-[128.63px]"
                    : index === 3
                      ? "w-[145.55px]"
                      : index === 4
                        ? "w-[125.24px]"
                        : "w-[110.57px]"
            }`}
            alt={logo.alt}
            src={logo.src}
          />
        ))}
      </div>
    </div>
  );
};

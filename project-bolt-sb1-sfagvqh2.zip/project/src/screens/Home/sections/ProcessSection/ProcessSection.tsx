import { PlusIcon } from "lucide-react";
import React from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "../../../../components/ui/accordion";

export const ProcessSection = (): JSX.Element => {
  // Process steps data for mapping
  const processSteps = [
    {
      id: "01",
      title: "Consultation",
      content:
        "During the initial consultation, we will discuss your business goals and objectives, target audience, and current marketing efforts. This will allow us to understand your needs and tailor our services to best fit your requirements.",
    },
    {
      id: "02",
      title: "Research and Strategy Development",
      content: "",
    },
    {
      id: "03",
      title: "Implementation",
      content: "",
    },
    {
      id: "04",
      title: "Monitoring and Optimization",
      content: "",
    },
    {
      id: "05",
      title: "Reporting and Communication",
      content: "",
    },
    {
      id: "06",
      title: "Continual Improvement",
      content: "",
    },
  ];

  return (
    <section className="flex flex-col items-start gap-[30px] px-[100px] py-0 w-full">
      <Accordion type="single" collapsible defaultValue="01" className="w-full">
        {processSteps.map((step) => (
          <AccordionItem
            key={step.id}
            value={step.id}
            className={`flex flex-col w-full items-start mb-[30px] px-[60px] py-[41px] rounded-[45px] overflow-hidden border border-solid border-[#191a23] shadow-[0px_5px_0px_#191a23] ${
              step.id === "01" ? "bg-green" : "bg-grey"
            }`}
          >
            <AccordionTrigger className="flex w-full items-center justify-between">
              <div className="inline-flex items-center gap-[25px]">
                <div
                  className={`relative w-fit mt-[-1.00px] [font-family:'Space_Grotesk',Helvetica] font-medium text-6xl tracking-[0] leading-[normal] ${
                    step.id === "01" ? "text-white" : "text-[#000000]"
                  }`}
                >
                  {step.id}
                </div>
                <div
                  className={`relative w-[612px] [font-family:'Space_Grotesk',Helvetica] font-medium text-3xl tracking-[0] leading-[normal] ${
                    step.id === "01"
                      ? "text-white"
                      : step.id === "06"
                        ? "text-[#191a23]"
                        : "text-[#000000]"
                  }`}
                >
                  {step.title}
                </div>
              </div>
              <PlusIcon className="relative w-[58px] h-[58px] shrink-0 transition-transform duration-200" />
            </AccordionTrigger>

            {step.content && (
              <AccordionContent>
                <div className="w-full pt-4">
                  <div className="w-full h-px bg-white mb-4" />
                  <div className="relative w-full font-p font-[number:var(--p-font-weight)] text-white text-[length:var(--p-font-size)] tracking-[var(--p-letter-spacing)] leading-[var(--p-line-height)] [font-style:var(--p-font-style)]">
                    {step.content}
                  </div>
                </div>
              </AccordionContent>
            )}
          </AccordionItem>
        ))}
      </Accordion>
    </section>
  );
};

import React from "react";
import { Button } from "../../../../components/ui/button";
import { Card, CardContent } from "../../../../components/ui/card";

export const CallToActionSection = (): JSX.Element => {
  return (
    <section className="w-full py-16">
      <div className="container flex items-center justify-between relative">
        <Card className="w-full bg-grey rounded-[45px] border-none">
          <CardContent className="flex items-center justify-between p-[60px]">
            <div className="flex flex-col gap-[26px] max-w-[500px]">
              <h3 className="font-h-3 text-[length:var(--h-3-font-size)] font-[number:var(--h-3-font-weight)] tracking-[var(--h-3-letter-spacing)] leading-[var(--h-3-line-height)] [font-style:var(--h-3-font-style)]">
                Let&apos;s make things happen
              </h3>
              <p className="font-p text-[length:var(--p-font-size)] font-[number:var(--p-font-weight)] tracking-[var(--p-letter-spacing)] leading-[var(--p-line-height)] [font-style:var(--p-font-style)]">
                Contact us today to learn more about how our digital marketing
                services can help your business grow and succeed online.
              </p>
              <Button className="bg-dark text-white rounded-[14px] px-[35px] py-5 h-auto">
                <span className="[font-family:'Space_Grotesk',Helvetica] font-normal text-xl leading-7">
                  Get your free proposal
                </span>
              </Button>
            </div>

            <div className="relative w-[494px] h-[394px]">
              <div className="w-[359px] h-[394px] rotate-180">
                <div className="relative w-[357px] h-[394px] left-0.5">
                  <div className="absolute w-[338px] h-[71px] top-40 left-[19px] rounded-[169px/35.5px] border border-solid border-[#000000] rotate-180" />
                  <div className="absolute w-[338px] h-[71px] top-[135px] left-[19px] rounded-[169px/35.5px] border border-solid border-[#000000] rotate-180" />
                  <div className="absolute w-[338px] h-[71px] top-[110px] left-[19px] rounded-[169px/35.5px] border border-solid border-[#000000] rotate-180" />
                  <img
                    className="w-[199px] h-[209px] top-[185px] left-[17px] absolute -rotate-180"
                    alt="Star"
                    src="/star-2.svg"
                  />
                  <img
                    className="w-40 h-[156px] top-[61px] left-0 absolute -rotate-180"
                    alt="Star"
                    src="/star-4.svg"
                  />
                  <img
                    className="absolute w-[130px] h-[130px] top-0 left-[157px] -rotate-180"
                    alt="Vector"
                    src="/vector-13.svg"
                  />
                  <div className="absolute w-[125px] h-[125px] top-[145px] left-[142px] bg-[#000000] rounded-[62.5px] border border-solid rotate-180" />
                  <div className="absolute w-5 h-10 top-[201px] left-[215px] bg-white rounded-[10px/20px] rotate-180" />
                  <div className="absolute w-5 h-10 top-[201px] left-[174px] bg-white rounded-[10px/20px] rotate-180" />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
};

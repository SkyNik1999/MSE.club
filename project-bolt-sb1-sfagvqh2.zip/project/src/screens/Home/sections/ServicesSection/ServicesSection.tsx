import { ArrowRightIcon } from "lucide-react";
import React from "react";
import { Button } from "../../../../components/ui/button";
import { Card, CardContent } from "../../../../components/ui/card";

// Service card data for mapping
const serviceCards = [
  {
    title: ["Student Accommodation", "Assistance"],
    bgColor: "bg-grey",
    textColor: "text-black",
    buttonBgColor: "bg-dark",
    buttonTextColor: "text-white-text",
    image: "/tokyo-magnifier-web-search-with-elements-2.png",
    imageAlt: "Tokyo magnifier web",
    imageWidth: "w-[210px]",
    imageHeight: "h-[166px]",
    imagePosition: "top-0.5 left-0",
  },
  {
    title: ["Student Pickup", "& Drop Services"],
    bgColor: "bg-green",
    textColor: "text-white-text",
    buttonBgColor: "bg-dark",
    buttonTextColor: "text-white-text",
    image: "/tokyo-selecting-a-value-in-the-browser-window-1.png",
    imageAlt: "Tokyo selecting a value",
    imageWidth: "w-[210px]",
    imageHeight: "h-[147.62px]",
    backgroundImage: true,
  },
  {
    title: ["Part-Time Job", "Assistance"],
    bgColor: "bg-dark",
    textColor: "text-white-text",
    buttonBgColor: "bg-white",
    buttonTextColor: "text-white",
    image: "/tokyo-browser-window-with-emoticon-likes-and-stars-around-2.png",
    imageAlt: "Tokyo browser window",
    imageWidth: "w-[209px]",
    imageHeight: "h-[210px]",
    imagePosition: "top-0 left-px",
  },
  {
    title: ["Education Consultation", "Services"],
    bgColor: "bg-grey",
    textColor: "text-black",
    buttonBgColor: "bg-dark",
    buttonTextColor: "text-white-text",
    image: "/tokyo-sending-messages-from-one-place-to-another-1.png",
    imageAlt: "Tokyo sending",
    imageWidth: "w-[210px]",
    imageHeight: "h-[192.68px]",
    imageMargin: "ml-[-65px]",
  },
  {
    title: ["Startup", "Incubation"],
    bgColor: "bg-green",
    textColor: "text-white-text",
    buttonBgColor: "bg-dark",
    buttonTextColor: "text-white-text",
    image: "/tokyo-many-browser-windows-with-different-information-1.png",
    imageAlt: "Tokyo many browser windows",
    imageWidth: "w-[210px]",
    imageHeight: "h-[195.91px]",
    backgroundImage: true,
  },
  {
    title: ["Events", ""],
    bgColor: "bg-dark",
    textColor: "text-white-text",
    buttonBgColor: "bg-white",
    buttonTextColor: "text-white",
    image:
      "/tokyo-volumetric-analytics-of-different-types-in-web-browsers-2.png",
    imageAlt: "Tokyo volumetric analytics",
    imageWidth: "w-[210px]",
    imageHeight: "h-[170px]",
    backgroundImage: true,
  },
];

export const ServicesSection = (): JSX.Element => {
  return (
    <section className="flex flex-col items-start gap-10 w-full py-10">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-10 px-4 md:px-[100px] w-full">
        {serviceCards.map((card, index) => (
          <Card
            key={index}
            className={`flex items-center justify-between p-[50px] ${card.bgColor} rounded-[45px] overflow-hidden border border-solid border-[#191a23] shadow-[0px_5px_0px_#191a23]`}
          >
            <CardContent className="p-0 flex items-center justify-between w-full">
              <div className="flex flex-col items-start justify-center gap-[93px]">
                <div className="flex flex-col items-start">
                  {card.title.map(
                    (line, i) =>
                      line && (
                        <div key={i} className="px-[7px] py-0 rounded-[7px]">
                          <div
                            className={`font-h-3 font-[number:var(--h-3-font-weight)] ${card.textColor} text-[length:var(--h-3-font-size)] tracking-[var(--h-3-letter-spacing)] leading-[var(--h-3-line-height)] [font-style:var(--h-3-font-style)]`}
                          >
                            {line}
                          </div>
                        </div>
                      ),
                  )}
                </div>

                <div className="flex items-center gap-[15px]">
                  <Button
                    variant="outline"
                    size="icon"
                    className={`w-[41px] h-[41px] ${card.buttonBgColor} rounded-[20.5px] p-0 border-none`}
                  >
                    <ArrowRightIcon className="w-5 h-5" />
                  </Button>
                  <span
                    className={`font-['Space_Grotesk',Helvetica] font-normal ${card.textColor} text-xl tracking-[0] leading-7 whitespace-nowrap`}
                  >
                    Learn more
                  </span>
                </div>
              </div>

              {card.backgroundImage ? (
                <div
                  className={`${card.imageWidth} ${card.imageHeight} bg-[url(${card.image})] bg-[100%_100%]`}
                  aria-label={card.imageAlt}
                />
              ) : (
                <div
                  className={`relative ${card.imageWidth} ${card.imageHeight} ${card.imageMargin || ""}`}
                >
                  <img
                    className={`absolute ${card.imageWidth} ${card.imageHeight} ${card.imagePosition || ""}`}
                    alt={card.imageAlt}
                    src={card.image}
                  />
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
};

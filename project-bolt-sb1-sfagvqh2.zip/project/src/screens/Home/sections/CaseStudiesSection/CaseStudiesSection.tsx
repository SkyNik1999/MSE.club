import React from "react";
import { Card, CardContent } from "../../../../components/ui/card";
import { Separator } from "../../../../components/ui/separator";

export const CaseStudiesSection = (): JSX.Element => {
  // Case studies data for mapping
  const caseStudies = [
    {
      description:
        "For a local restaurant, we implemented a targeted PPC campaign that resulted in a 50% increase in website traffic and a 25% increase in sales.",
      iconSrc: "/icon.png",
    },
    {
      description:
        "For a B2B software company, we developed an SEO strategy that resulted in a first page ranking for key keywords and a 200% increase in organic traffic.",
      iconSrc: "/icon-1.png",
    },
    {
      description:
        "For a national retail chain, we created a social media marketing campaign that increased followers by 25% and generated a 20% increase in online sales.",
      iconSrc: "/icon-2.png",
    },
  ];

  return (
    <section className="w-full py-16 px-4 md:px-[100px]">
      <Card className="bg-dark rounded-[45px] border-none">
        <CardContent className="flex flex-col md:flex-row justify-between items-start gap-8 p-[60px] py-[70px]">
          {caseStudies.map((study, index) => (
            <React.Fragment key={index}>
              <div className="flex flex-col gap-5">
                <p className="w-[286px] font-p font-[number:var(--p-font-weight)] text-white text-[length:var(--p-font-size)] tracking-[var(--p-letter-spacing)] leading-[var(--p-line-height)] [font-style:var(--p-font-style)]">
                  {study.description}
                </p>
                <div className="flex items-center gap-[15px]">
                  <span className="font-['Space_Grotesk',Helvetica] font-normal text-green text-xl leading-7 whitespace-nowrap">
                    Learn more
                  </span>
                  <img
                    className="w-[20.32px] h-[19.53px]"
                    alt="Icon"
                    src={study.iconSrc}
                  />
                </div>
              </div>
              {index < caseStudies.length - 1 && (
                <Separator
                  orientation="vertical"
                  className="h-[186px] bg-white/20"
                />
              )}
            </React.Fragment>
          ))}
        </CardContent>
      </Card>
    </section>
  );
};
